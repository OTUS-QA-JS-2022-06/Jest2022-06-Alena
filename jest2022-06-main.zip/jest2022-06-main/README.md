© Здесь могла бы быть ваша реклама)

# Templater

### Установка

- Сделайте форк проекта.
- Скачайте проект локально
- Выполните npm install

### Запуск тестов

```sh
npm test
```

### Домашнее задание

Домашние задания, а точнее папка с тестами, прячется в каталоге `specs`.
Для ревью домашнего задания присылайте в чат ссылку с pull request в fork СВОЕГО проекта.
И не забывайте делать rebase, на основной проект)

### Остались вопросы?

Пишите в чате группы в Slack.

### Настройка окружения?

Для того, чтобы Webstorm, не подчеркивал describe и test.

In Preferences | Languages & Frameworks | JavaScript | Libraries, press  **Download...** , select *'jest'* from the list of available stubs, press **Download and Install**
