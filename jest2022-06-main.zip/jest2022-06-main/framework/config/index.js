import urls from './urls';

export default urls;
