const urls = {
  reqres: 'https://reqres.in/',
};

export default urls;
